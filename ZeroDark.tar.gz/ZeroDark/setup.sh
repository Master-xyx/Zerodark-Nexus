#!/bin/bash

# Colors
GREEN="\e[92m"
RESET="\e[0m"

echo -e "${GREEN}[+] Updating Termux packages...${RESET}"
pkg update -y && pkg upgrade -y

echo -e "${GREEN}[+] Installing required packages...${RESET}"
pkg install -y proot wget nano nodejs yarn


# Setup project
if [ ! -d "$HOME/ZeroDark" ]; then
    echo -e "${GREEN}[+] Creating project folder...${RESET}"
    mkdir -p ~/ZeroDark
fi

if [ -d "server" ]; then
    cd server || exit
    echo -e "${GREEN}[+] Installing Node.js dependencies...${RESET}"
    npm install
    cd ~
fi

# Add aliases to .bashrc (avoid duplicates)
if ! grep -q "alias admin0=" ~/.bashrc; then
    echo "alias admin0='cd ~/ZeroDark/server && node index.js'" >> ~/.bashrc
fi

if ! grep -q "alias pass0=" ~/.bashrc; then
    echo "alias pass0='bash ~/ZeroDark/pass0'" >> ~/.bashrc
fi

# Final message
clear
echo -e "${GREEN}[✔] Installation complete!${RESET}"
echo -e "${GREEN}[✔] Type: admin0 to start the server${RESET}"
echo -e "${GREEN}[✔] Type: pass0 to run password script${RESET}"
sleep 2
echo -e "${GREEN}Subscribe my YouTube channel – Thanks!${RESET}"

# Open YouTube channel
termux-open-url "https://youtu.be/XKAEIqOCNoY"

# Remove setup script
rm -f setup.sh
