#!/bin/bash

# Update & install basic packages
echo -e "\e[92m[+] Updating packages...\e[0m"
pkg update -y && pkg upgrade -y

echo -e "\e[92m[+] Installing required packages...\e[0m"
pkg install proot wget nano nodejs yarn -y

pkg remove openjdk-17 -y 2>/dev/null

cd server
npm install
mkdir ~/zerodark
cd
echo "alias admin0='cd ~/ZeroDark/server && node index.js'" >> ~/.bashrc
echo "alias pass0='alias pass0='bash ZeroDark/pass0'" >> ~/.bashrc

clear
echo -e "\e[1;92m[✔]Type admin0 Installation complete!\e[0m"
sleep 2
echo -e "\e[1;92m Subscribe my YouTube channel – Thanks!\e[0m"
rm setup.sh
termux-open-url https://youtu.be/XKAEIqOCNoY
